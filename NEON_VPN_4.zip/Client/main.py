import customtkinter as ctk
import requests
import threading
import queue
import time
import os
import socket
import json
from cryptography.fernet import Fernet
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from tkinter import messagebox, simpledialog

SERVER_URL = "http://127.0.0.1:5000"

BG = ("#F2F5FC", "#050611")
SIDEBAR = ("#E1E8F6", "#0A0D1E")
CARD = ("#FFFFFF", "#10162A")
INNER = ("#EAF0FA", "#080E20")

CYAN = ("#126B9C", "#00F0FF")
PURPLE = ("#7545B8", "#B54CFF")
PINK = ("#B82A83", "#FF3DC8")
WHITE = ("#18243A", "#F5F4FF")
GRAY = ("#52637C", "#91A1C5")
GREEN = ("#087E61", "#42FFBD")
RED = ("#BA3159", "#FF527F")

ctk.set_appearance_mode("dark")

TEXT = {
    "English": {"login": "LOG IN", "signup": "SIGN UP", "back": "BACK TO LOG IN", "username": "USERNAME",
                "password": "PASSWORD", "confirm": "CONFIRM PASSWORD", "access": "ACCESS TERMINAL",
                "verify": "IDENTITY VERIFICATION // REQUIRED", "new": "NEW IDENTITY",
                "create": "CREATE A NEON NETWORK ACCOUNT", "ready": "● SYSTEM READY",
                "contact": "● CONTACTING SERVER...", "empty": "ENTER USERNAME AND PASSWORD",
                "user_error": "USERNAME MUST BE 1-50 CHARACTERS",
                "pass_error": "PASSWORD MUST HAVE AT LEAST 8 CHARACTERS", "match_error": "PASSWORDS DO NOT MATCH",
                "created": "ACCOUNT CREATED! PLEASE LOG IN.", "center": "◈ CONTROL CENTER", "offline": "● VPN OFFLINE",
                "welcome": "WELCOME BACK", "inactive": "VPN TUNNEL IS NOT ACTIVE", "disconnected": "DISCONNECTED",
                "connect": "CONNECT VPN", "engine": "VPN ENGINE NOT CONFIGURED", "server": "SERVER",
                "not_selected": "NOT SELECTED", "protocol": "PROTOCOL", "planned": "WIREGUARD (PLANNED)",
                "session": "SESSION", "logout": "LOG OUT", "settings": "SETTINGS", "theme": "APPEARANCE",
                "language": "LANGUAGE", "dark": "Dark", "light": "Light", "save_note": "Changes apply immediately",
                "system": "SYSTEM // 01"},
    "Русский": {"login": "ВОЙТИ", "signup": "РЕГИСТРАЦИЯ", "back": "НАЗАД КО ВХОДУ", "username": "ИМЯ ПОЛЬЗОВАТЕЛЯ",
                "password": "ПАРОЛЬ", "confirm": "ПОВТОРИТЕ ПАРОЛЬ", "access": "ВХОД В СИСТЕМУ",
                "verify": "ПРОВЕРКА УЧЁТНОЙ ЗАПИСИ", "new": "НОВЫЙ АККАУНТ", "create": "СОЗДАТЬ УЧЁТНУЮ ЗАПИСЬ",
                "ready": "● СИСТЕМА ГОТОВА", "contact": "● СВЯЗЬ С СЕРВЕРОМ...", "empty": "ВВЕДИТЕ ЛОГИН И ПАРОЛЬ",
                "user_error": "ЛОГИН: ОТ 1 ДО 50 СИМВОЛОВ", "pass_error": "ПАРОЛЬ: МИНИМУМ 8 СИМВОЛОВ",
                "match_error": "ПАРОЛИ НЕ СОВПАДАЮТ", "created": "АККАУНТ СОЗДАН! ВОЙДИТЕ.",
                "center": "◈ ЦЕНТР УПРАВЛЕНИЯ", "offline": "● VPN ВЫКЛЮЧЕН", "welcome": "С ВОЗВРАЩЕНИЕМ",
                "inactive": "VPN-СОЕДИНЕНИЕ НЕ АКТИВНО", "disconnected": "НЕ ПОДКЛЮЧЕНО", "connect": "ПОДКЛЮЧИТЬ VPN",
                "engine": "VPN ЕЩЁ НЕ НАСТРОЕН", "server": "СЕРВЕР", "not_selected": "НЕ ВЫБРАН",
                "protocol": "ПРОТОКОЛ", "planned": "WIREGUARD (В ПЛАНАХ)", "session": "СЕССИЯ", "logout": "ВЫЙТИ",
                "settings": "НАСТРОЙКИ", "theme": "ТЕМА", "language": "ЯЗЫК", "dark": "Тёмная", "light": "Светлая",
                "save_note": "Изменения применяются сразу", "system": "СИСТЕМА // 01"},
    "עברית": {"login": "כניסה", "signup": "הרשמה", "back": "חזרה לכניסה", "username": "שם משתמש", "password": "סיסמה",
              "confirm": "אימות סיסמה", "access": "כניסה למערכת", "verify": "אימות משתמש", "new": "חשבון חדש",
              "create": "יצירת חשבון חדש", "ready": "● המערכת מוכנה", "contact": "● מתחבר לשרת...",
              "empty": "יש להזין שם משתמש וסיסמה", "user_error": "שם משתמש: 1 עד 50 תווים",
              "pass_error": "סיסמה: לפחות 8 תווים", "match_error": "הסיסמאות אינן תואמות",
              "created": "החשבון נוצר! אפשר להתחבר.", "center": "◈ מרכז הבקרה", "offline": "● VPN מנותק",
              "welcome": "ברוך שובך", "inactive": "חיבור VPN אינו פעיל", "disconnected": "מנותק",
              "connect": "התחברות ל-VPN", "engine": "שירות VPN טרם הוגדר", "server": "שרת", "not_selected": "לא נבחר",
              "protocol": "פרוטוקול", "planned": "WIREGUARD (בתכנון)", "session": "משך חיבור", "logout": "יציאה",
              "settings": "הגדרות", "theme": "ערכת נושא", "language": "שפה", "dark": "כהה", "light": "בהירה",
              "save_note": "השינויים חלים מיד", "system": "מערכת // 01"}
}


TEXT["English"].update({"connecting": "CONNECTING...", "connected": "CONNECTED (DEMO)", "disconnect": "DISCONNECT VPN", "demo": "DEMO MODE — NO REAL VPN TUNNEL", "choose_server": "SELECT DEMO SERVER", "demo_protocol": "SIMULATION", "demo_status": "● DEMO CONNECTED", "demo_wait": "● CONNECTING...", "server_required": "SELECT A SERVER FIRST"})
TEXT["Русский"].update({"connecting": "ПОДКЛЮЧЕНИЕ...", "connected": "ПОДКЛЮЧЕНО (ДЕМО)", "disconnect": "ОТКЛЮЧИТЬ VPN", "demo": "ДЕМОРЕЖИМ — НАСТОЯЩЕГО VPN НЕТ", "choose_server": "ВЫБЕРИТЕ ДЕМОСЕРВЕР", "demo_protocol": "СИМУЛЯЦИЯ", "demo_status": "● ДЕМО ПОДКЛЮЧЕНО", "demo_wait": "● ПОДКЛЮЧЕНИЕ...", "server_required": "СНАЧАЛА ВЫБЕРИТЕ СЕРВЕР"})
TEXT["עברית"].update({"connecting": "מתחבר...", "connected": "מחובר (הדגמה)", "disconnect": "ניתוק VPN", "demo": "מצב הדגמה — אין חיבור VPN אמיתי", "choose_server": "בחירת שרת הדגמה", "demo_protocol": "הדמיה", "demo_status": "● מחובר להדגמה", "demo_wait": "● מתחבר...", "server_required": "יש לבחור שרת תחילה"})


class EncryptionManager:
    def __init__(self):
        self.cipher = Fernet(os.environ["NEON_KEY"].encode())

    def encrypt(self, data):
        return self.cipher.encrypt(json.dumps(data).encode()).decode()


class NetworkClient:
    def __init__(self):
        self.encryption = EncryptionManager()

    def post(self, route, username, password):
        with socket.create_connection(("127.0.0.1", 5000), timeout=3):
            pass
        token = self.encryption.encrypt({"username": username, "password": password})
        return requests.post(SERVER_URL + route, json={"token": token}, timeout=10)


class AIAssistant:
    def __init__(self):
        examples = ["server offline", "cannot connect server", "connection refused", "сервер недоступен", "не работает сервер", "password incorrect", "invalid login password", "forgot password", "неверный пароль", "ошибка входа", "vpn demo", "real tunnel", "change vpn server", "демо впн", "настоящий впн"]
        labels = ["server"] * 5 + ["login"] * 5 + ["demo"] * 5
        self.vectorizer = TfidfVectorizer()
        self.model = MultinomialNB()
        self.model.fit(self.vectorizer.fit_transform(examples), labels)

    def answer(self, question):
        features = self.vectorizer.transform([question])
        if features.nnz == 0:
            return "Please ask about server, login or VPN demo."
        category = self.model.predict(features)[0]
        return {"server": "Check that Flask is running on port 5000.", "login": "Check your username and password. Register if needed.", "demo": "VPN connection is simulated; no traffic is routed."}[category]


class VPNManager:
    def elapsed(self, started):
        if started is None:
            return "00:00:00"
        seconds = int(time.monotonic() - started)
        return f"{seconds // 3600:02d}:{seconds % 3600 // 60:02d}:{seconds % 60:02d}"


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.network = NetworkClient()
        self.ai = AIAssistant()
        self.vpn = VPNManager()

        self.title("NEON // VPN - NIGHT CITY")
        self.geometry("1060x680")
        self.minsize(960, 630)
        self.configure(fg_color=BG)

        self.language = "English"
        self.theme = "Dark"
        self.current_username = None
        self.demo_state = "offline"
        self.demo_server = "Germany"
        self.demo_started = None
        self.demo_job = None
        self.demo_status_label = None
        self.demo_detail_label = None
        self.demo_button = None
        self.demo_timer_label = None
        self.demo_header_label = None
        self.demo_server_menu = None
        self.busy = False
        self.page = ""
        self.results = queue.Queue()

        self.username_entry = None
        self.password_entry = None
        self.confirm_entry = None
        self.status = None
        self.action_button = None

        self.sidebar = ctk.CTkFrame(
            self,
            width=230,
            fg_color=SIDEBAR,
            corner_radius=0
        )
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        ctk.CTkLabel(
            self.sidebar,
            text="◈ NEON",
            font=("Consolas", 34, "bold"),
            text_color=CYAN
        ).pack(pady=(40, 0))

        ctk.CTkLabel(
            self.sidebar,
            text="// VIRTUAL NETWORK",
            font=("Consolas", 11),
            text_color=PINK
        ).pack(pady=(0, 35))

        ctk.CTkFrame(
            self.sidebar,
            height=3,
            fg_color=PURPLE
        ).pack(fill="x", padx=22)

        self.nav = ctk.CTkLabel(
            self.sidebar,
            text="> LOG IN",
            font=("Consolas", 15, "bold"),
            text_color=CYAN
        )
        self.nav.pack(
            anchor="w",
            padx=25,
            pady=(35, 20)
        )

        self.settings_button = ctk.CTkButton(
            self.sidebar,
            text=self.t("settings"),
            command=self.show_settings,
            fg_color=("#E4D9F4", "#281541"),
            hover_color=PURPLE,
            text_color=WHITE,
            font=("Consolas", 13, "bold")
        )
        self.settings_button.pack(fill="x", padx=22, pady=(0, 12))
        ctk.CTkButton(self.sidebar, text="AI HELP", command=self.show_ai).pack(fill="x", padx=22)

        ctk.CTkLabel(
            self.sidebar,
            text="SYSTEM // 01",
            font=("Consolas", 12, "bold"),
            text_color=PINK
        ).pack(
            anchor="w",
            padx=25,
            pady=(55, 10)
        )

        ctk.CTkLabel(
            self.sidebar,
            text=(
                "● CLIENT ONLINE\n\n"
                "○ VPN OFFLINE\n\n"
                "◇ API: LOCALHOST"
            ),
            font=("Consolas", 11),
            text_color=GRAY,
            justify="left"
        ).pack(anchor="w", padx=25)

        ctk.CTkLabel(
            self.sidebar,
            text="N E O N   / /   4 . 0",
            font=("Consolas", 10),
            text_color=PURPLE
        ).pack(side="bottom", pady=28)

        self.content = ctk.CTkFrame(
            self,
            fg_color=BG,
            corner_radius=0
        )
        self.content.pack(
            side="left",
            fill="both",
            expand=True
        )

        self.show_login()
        self.after(50, self.process_results)
        self.after(1000, self.update_demo_timer)

    def show_ai(self):
        question = simpledialog.askstring("AI HELP", "Ask about server, login or VPN demo:", parent=self)
        if question:
            messagebox.showinfo("AI HELP", self.ai.answer(question), parent=self)

    def t(self, key):
        return TEXT[self.language][key]

    def change_theme(self, value):
        self.theme = value
        ctk.set_appearance_mode("light" if value == "Light" else "dark")
        self.refresh_page()

    def change_language(self, value):
        self.language = value
        self.settings_button.configure(text=self.t("settings"))
        self.refresh_page()

    def demo_connect(self):
        if self.demo_state == "connected":
            self.demo_state = "offline"
            self.demo_started = None
            if self.demo_job is not None:
                self.after_cancel(self.demo_job)
                self.demo_job = None
            self.update_demo_display()
        elif self.demo_state == "offline":
            self.demo_state = "connecting"
            self.update_demo_display()
            self.demo_job = self.after(1200, self.finish_demo_connect)

    def finish_demo_connect(self):
        self.demo_job = None
        if self.demo_state == "connecting":
            self.demo_state = "connected"
            self.demo_started = time.monotonic()
            self.update_demo_display()

    def change_demo_server(self, value):
        self.demo_server = value
        if self.demo_state != "offline":
            self.demo_state = "offline"
            self.demo_started = None
            if self.demo_job is not None:
                self.after_cancel(self.demo_job)
                self.demo_job = None
        self.update_demo_display()

    def demo_time(self):
        return self.vpn.elapsed(self.demo_started)

    def update_demo_timer(self):
        if self.demo_state == "connected" and self.demo_timer_label is not None:
            if self.demo_timer_label.winfo_exists():
                self.demo_timer_label.configure(text=self.demo_time())
        self.after(1000, self.update_demo_timer)

    def update_demo_display(self):
        if self.page != "dashboard":
            return
        if self.demo_status_label is None or not self.demo_status_label.winfo_exists():
            return
        if self.demo_state == "connected":
            self.demo_status_label.configure(text=self.t("connected"), text_color=GREEN)
            self.demo_header_label.configure(text=self.t("demo_status"), text_color=GREEN)
            self.demo_button.configure(text=self.t("disconnect"), state="normal")
        elif self.demo_state == "connecting":
            self.demo_status_label.configure(text=self.t("connecting"), text_color=PURPLE)
            self.demo_header_label.configure(text=self.t("demo_wait"), text_color=PURPLE)
            self.demo_button.configure(text=self.t("connecting"), state="disabled")
        else:
            self.demo_status_label.configure(text=self.t("disconnected"), text_color=RED)
            self.demo_header_label.configure(text=self.t("offline"), text_color=RED)
            self.demo_button.configure(text=self.t("connect"), state="normal")
        self.demo_timer_label.configure(text=self.demo_time())

    def refresh_page(self):
        if self.page == "dashboard":
            self.show_dashboard(self.current_username)
        elif self.page == "register":
            self.show_register()
        elif self.page == "settings":
            self.show_settings()
        else:
            self.show_login()

    def show_settings(self):
        self.clear()
        self.page = "settings"
        self.nav.configure(text="> " + self.t("settings"))
        panel = ctk.CTkFrame(self.content, fg_color=CARD, corner_radius=20)
        panel.pack(fill="both", expand=True, padx=35, pady=35)
        ctk.CTkLabel(panel, text=self.t("settings"), text_color=CYAN,
                     font=("Consolas", 28, "bold")).pack(pady=(45, 25))
        ctk.CTkLabel(panel, text=self.t("theme"), text_color=WHITE,
                     font=("Consolas", 16)).pack(pady=(5, 8))
        ctk.CTkSegmentedButton(panel, values=["Dark", "Light"],
                               command=self.change_theme).pack(pady=(0, 25))

        theme_control = panel.winfo_children()[-1]
        theme_control.set(self.theme)
        ctk.CTkLabel(panel, text=self.t("language"), text_color=WHITE,
                     font=("Consolas", 16)).pack(pady=(0, 8))
        ctk.CTkOptionMenu(panel, values=["English", "Русский", "עברית"],
                          command=self.change_language, width=230).pack(pady=(0, 12))
        language_control = panel.winfo_children()[-1]
        language_control.set(self.language)
        ctk.CTkLabel(panel, text=self.t("save_note"), text_color=GRAY,
                     font=("Consolas", 12)).pack(pady=(5, 18))
        if self.current_username:
            self.button(panel, self.t("center"),
                        lambda: self.show_dashboard(self.current_username), False)
        else:
            self.button(panel, self.t("back"), self.show_login, False)

    def clear(self):
        self.demo_status_label = None
        self.demo_detail_label = None
        self.demo_button = None
        self.demo_timer_label = None
        self.demo_header_label = None
        self.demo_server_menu = None
        for widget in self.content.winfo_children():
            widget.destroy()

        self.username_entry = None
        self.password_entry = None
        self.confirm_entry = None
        self.status = None
        self.action_button = None

    def glow_card(self, parent, color=CYAN):
        outer = ctk.CTkFrame(
            parent,
            fg_color=("#CEDCF0", "#122B4A"),
            corner_radius=23
        )
        outer.pack(
            fill="both",
            expand=True,
            padx=32,
            pady=24
        )

        middle = ctk.CTkFrame(
            outer,
            fg_color=color,
            corner_radius=20
        )
        middle.pack(
            fill="both",
            expand=True,
            padx=3,
            pady=3
        )

        card = ctk.CTkFrame(
            middle,
            fg_color=CARD,
            corner_radius=18
        )
        card.pack(
            fill="both",
            expand=True,
            padx=2,
            pady=2
        )

        return card

    def title_block(self, parent, title, subtitle):
        ctk.CTkLabel(
            parent,
            text="◆ " + title,
            font=("Consolas", 28, "bold"),
            text_color=CYAN
        ).pack(pady=(32, 7))

        ctk.CTkLabel(
            parent,
            text=subtitle,
            font=("Consolas", 12),
            text_color=PINK
        ).pack(pady=(0, 15))

        ctk.CTkFrame(
            parent,
            height=3,
            fg_color=PURPLE
        ).pack(
            fill="x",
            padx=95,
            pady=(0, 22)
        )

    def entry(self, parent, placeholder, secret=False):
        item = ctk.CTkEntry(
            parent,
            width=380,
            height=47,
            corner_radius=8,
            fg_color=INNER,
            border_color=PURPLE,
            border_width=2,
            text_color=WHITE,
            placeholder_text=placeholder,
            font=("Consolas", 13),
            show="*" if secret else ""
        )
        item.pack(pady=9)
        return item

    def button(self, parent, text, command, primary=True):
        item = ctk.CTkButton(
            parent,
            text=text,
            command=command,
            width=380,
            height=48,
            corner_radius=8,
            font=("Consolas", 14, "bold"),
            fg_color=CYAN if primary else ("#E4D9F4", "#281541"),
            hover_color=PINK if primary else PURPLE,
            text_color=BG if primary else WHITE,
            border_width=0 if primary else 2,
            border_color=PURPLE
        )
        item.pack(pady=8)
        return item

    def set_status(self, message, success=False):
        if self.status is not None:
            self.status.configure(
                text=message,
                text_color=GREEN if success else RED
            )

    def status_label(self, parent):
        self.status = ctk.CTkLabel(
            parent,
            text=self.t("ready"),
            text_color=GREEN,
            font=("Consolas", 11),
            wraplength=400
        )
        self.status.pack(pady=15)

    def show_login(self):
        self.demo_state = "offline"
        self.demo_started = None
        if self.demo_job is not None:
            self.after_cancel(self.demo_job)
            self.demo_job = None
        self.clear()
        self.page = "login"
        self.current_username = None
        self.nav.configure(text="> " + self.t("login"))

        card = self.glow_card(self.content, CYAN)

        self.title_block(
            card,
            self.t("access"),
            self.t("verify")
        )

        self.username_entry = self.entry(
            card,
            self.t("username")
        )

        self.password_entry = self.entry(
            card,
            self.t("password"),
            True
        )

        self.action_button = self.button(
            card,
            self.t("login") + "  →",
            self.login
        )

        self.button(
            card,
            self.t("signup"),
            self.show_register,
            False
        )

        self.status_label(card)
        self.username_entry.focus_set()

        self.password_entry.bind(
            "<Return>",
            lambda event: self.login()
        )

    def show_register(self):
        self.clear()
        self.page = "register"
        self.nav.configure(text="> " + self.t("signup"))

        card = self.glow_card(self.content, PURPLE)

        self.title_block(
            card,
            self.t("new"),
            self.t("create")
        )

        self.username_entry = self.entry(
            card,
            self.t("username")
        )

        self.password_entry = self.entry(
            card,
            self.t("password"),
            True
        )

        self.confirm_entry = self.entry(
            card,
            self.t("confirm"),
            True
        )

        self.action_button = self.button(
            card,
            self.t("signup") + "  →",
            self.register_user
        )

        self.button(
            card,
            self.t("back"),
            self.show_login,
            False
        )

        self.status_label(card)
        self.username_entry.focus_set()

        self.confirm_entry.bind(
            "<Return>",
            lambda event: self.register_user()
        )

    def send_request(self, route, username, password, callback):
        if self.busy:
            return

        self.busy = True
        page = self.page

        self.set_status(self.t("contact"), True)

        if self.action_button is not None:
            self.action_button.configure(state="disabled")

        def worker():
            try:
                response = self.network.post(route, username, password)

                try:
                    data = response.json()

                    if isinstance(data, dict):
                        message = str(
                            data.get("message", "Unknown response")
                        )
                    else:
                        message = "Invalid response"

                except ValueError:
                    message = "Invalid server response"

                result = (
                    response.status_code,
                    message
                )

            except (requests.RequestException, OSError):
                result = (
                    0,
                    "Cannot connect to server"
                )

            self.results.put(
                (page, callback, result)
            )

        threading.Thread(
            target=worker,
            daemon=True
        ).start()

    def process_results(self):
        try:
            while True:
                page, callback, result = (
                    self.results.get_nowait()
                )

                self.busy = False

                if self.page == page:
                    if self.action_button is not None:
                        self.action_button.configure(
                            state="normal"
                        )

                    callback(*result)

        except queue.Empty:
            pass

        self.after(50, self.process_results)

    def login(self):
        if self.busy:
            return

        username = self.username_entry.get().strip()
        password = self.password_entry.get()

        if not username or not password:
            self.set_status(
                self.t("empty")
            )
            return

        def finished(code, message):
            if code == 200:
                self.show_dashboard(username)
            else:
                self.set_status(message)

        self.send_request(
            "/login",
            username,
            password,
            finished
        )

    def register_user(self):
        if self.busy:
            return

        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        confirm = self.confirm_entry.get()

        if not username or len(username) > 50:
            self.set_status(
                self.t("user_error")
            )
            return

        if len(password) < 8:
            self.set_status(
                self.t("pass_error")
            )
            return

        if password != confirm:
            self.set_status(
                self.t("match_error")
            )
            return

        def finished(code, message):
            if code == 201:
                self.show_login()
                self.set_status(
                    self.t("created"),
                    True
                )
            else:
                self.set_status(message)

        self.send_request(
            "/register",
            username,
            password,
            finished
        )

    def dashboard_card(self, parent, title, value, color=CYAN):
        card = ctk.CTkFrame(
            parent,
            fg_color=CARD,
            corner_radius=14,
            border_width=1,
            border_color=("#C6D1E4", "#25314D")
        )
        card.pack(side="left", fill="both", expand=True, padx=5)

        ctk.CTkLabel(
            card,
            text=title,
            text_color=GRAY,
            font=("Consolas", 11)
        ).pack(pady=(15, 5))

        ctk.CTkLabel(
            card,
            text=value,
            text_color=color,
            font=("Consolas", 14, "bold")
        ).pack(pady=(0, 16))

        return card

    def show_dashboard(self, username):
        self.clear()
        self.page = "dashboard"
        self.nav.configure(text="> " + self.t("center"))
        self.current_username = username

        main = ctk.CTkScrollableFrame(
            self.content,
            fg_color=BG,
            corner_radius=0
        )
        main.pack(fill="both", expand=True, padx=14, pady=10)

        header = ctk.CTkFrame(main, fg_color="transparent")
        header.pack(fill="x", padx=18, pady=(12, 16))

        ctk.CTkLabel(
            header,
            text=self.t("center"),
            text_color=CYAN,
            font=("Consolas", 25, "bold")
        ).pack(side="left")

        self.demo_header_label = ctk.CTkLabel(
            header,
            text=self.t("offline"),
            text_color=RED,
            font=("Consolas", 12, "bold")
        )
        self.demo_header_label.pack(side="right")

        panel = ctk.CTkFrame(
            main,
            fg_color=CARD,
            corner_radius=20,
            border_width=1,
            border_color=("#C6D1E4", "#25314D")
        )
        panel.pack(fill="x", padx=18, pady=6)

        ctk.CTkLabel(
            panel,
            text=self.t("welcome") + ", " + username.upper(),
            text_color=WHITE,
            font=("Consolas", 21, "bold")
        ).pack(pady=(24, 6))

        ctk.CTkLabel(
            panel,
            text=self.t("demo"),
            text_color=GRAY,
            font=("Consolas", 12)
        ).pack(pady=(0, 18))

        connection = ctk.CTkFrame(
            panel,
            fg_color=INNER,
            corner_radius=18
        )
        connection.pack(fill="x", padx=24, pady=(0, 16))

        ctk.CTkLabel(
            connection,
            text="◉",
            text_color=PURPLE,
            font=("Consolas", 60, "bold")
        ).pack(pady=(12, 0))

        self.demo_status_label = ctk.CTkLabel(
            connection,
            text=self.t("disconnected"),
            text_color=RED,
            font=("Consolas", 20, "bold")
        )
        self.demo_status_label.pack(pady=(0, 10))

        self.demo_button = ctk.CTkButton(
            connection,
            text=self.t("connect"),
            command=self.demo_connect,
            width=260,
            height=44,
            corner_radius=10,
            fg_color=CYAN,
            hover_color=PURPLE,
            text_color=BG,
            font=("Consolas", 14, "bold")
        )
        self.demo_button.pack(pady=(0, 8))

        ctk.CTkLabel(
            connection,
            text=self.t("demo"),
            text_color=GRAY,
            font=("Consolas", 11)
        ).pack(pady=(0, 15))

        ctk.CTkLabel(
            connection,
            text=self.t("choose_server"),
            text_color=WHITE,
            font=("Consolas", 12)
        ).pack(pady=(5, 5))

        self.demo_server_menu = ctk.CTkOptionMenu(
            connection,
            values=["Germany", "Netherlands", "USA"],
            command=self.change_demo_server,
            width=260,
            fg_color=PURPLE,
            button_color=PURPLE
        )
        self.demo_server_menu.pack(pady=(0, 15))
        self.demo_server_menu.set(self.demo_server)

        info = ctk.CTkFrame(panel, fg_color="transparent")
        info.pack(fill="x", padx=18, pady=(0, 18))

        self.dashboard_card(info, self.t("server"), self.demo_server, CYAN)
        self.dashboard_card(info, self.t("protocol"), self.t("demo_protocol"), PURPLE)
        timer_card = self.dashboard_card(info, self.t("session"), self.demo_time(), GREEN)
        self.demo_timer_label = timer_card.winfo_children()[-1]
        self.update_demo_display()

        ctk.CTkButton(
            main,
            text=self.t("logout"),
            command=self.show_login,
            width=260,
            height=44,
            corner_radius=10,
            fg_color=("#E4D9F4", "#281541"),
            hover_color=PURPLE,
            text_color=WHITE,
            font=("Consolas", 13, "bold")
        ).pack(pady=(14, 20))


if __name__ == "__main__":
    app = App()
    app.mainloop()