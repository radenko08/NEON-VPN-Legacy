import os
import json
import mysql.connector
from flask import Flask, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from cryptography.fernet import Fernet, InvalidToken

app = Flask(__name__)


class Database:
    def connection(self):
        return mysql.connector.connect(host="127.0.0.1", port=3306, user="vpn_user", password=os.environ["VPN_DB_PASSWORD"], database="VPN")

    def execute(self, query, values, fetch=False):
        db = self.connection()
        cursor = None
        try:
            cursor = db.cursor()
            cursor.execute(query, values)
            if fetch:
                return cursor.fetchone()
            db.commit()
        finally:
            if cursor is not None:
                cursor.close()
            db.close()


class EncryptionManager:
    def __init__(self):
        self.cipher = Fernet(os.environ["NEON_KEY"].encode())

    def decrypt(self, token):
        return json.loads(self.cipher.decrypt(token.encode(), ttl=60))


database = Database()


def credentials():
    data = request.get_json(silent=True)
    if not isinstance(data, dict) or not isinstance(data.get("token"), str):
        raise ValueError("Missing token")
    data = EncryptionManager().decrypt(data["token"])
    if not isinstance(data, dict):
        raise ValueError("Invalid data")
    username = data.get("username")
    password = data.get("password")
    if not isinstance(username, str) or not isinstance(password, str):
        raise ValueError("Invalid credentials")
    return username.strip(), password


@app.post("/register")
def register():
    try:
        username, password = credentials()
    except (InvalidToken, ValueError, TypeError):
        return jsonify(message="Invalid encrypted request"), 400
    if not username or len(username) > 50:
        return jsonify(message="Username must contain 1-50 characters"), 400
    if len(password) < 8:
        return jsonify(message="Password must contain at least 8 characters"), 400
    try:
        database.execute("INSERT INTO users (username, password_hash) VALUES (%s, %s)", (username, generate_password_hash(password)))
        return jsonify(message="Account created successfully"), 201
    except mysql.connector.IntegrityError:
        return jsonify(message="Username already exists"), 409
    except mysql.connector.Error:
        return jsonify(message="Database unavailable"), 503


@app.post("/login")
def login():
    try:
        username, password = credentials()
    except (InvalidToken, ValueError, TypeError):
        return jsonify(message="Invalid encrypted request"), 400
    if not username or len(username) > 50 or not password:
        return jsonify(message="Enter username and password"), 400
    try:
        row = database.execute("SELECT password_hash FROM users WHERE username = %s", (username,), True)
        if row and check_password_hash(row[0], password):
            return jsonify(message="Login successful"), 200
        return jsonify(message="Invalid username or password"), 401
    except mysql.connector.Error:
        return jsonify(message="Database unavailable"), 503


if __name__ == "__main__":
    EncryptionManager()
    app.run(host="127.0.0.1", port=5000, debug=False)
